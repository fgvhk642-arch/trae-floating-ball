import os

# 悬浮球配置
FLOATING_BALL_SIZE = 60
FLOATING_BALL_COLOR = '#667eea'
FLOATING_BALL_HOVER_COLOR = '#764ba2'

# 聊天窗口配置
CHAT_WINDOW_WIDTH = 400
CHAT_WINDOW_HEIGHT = 600

# 历史记录配置
MAX_HISTORY_SIZE = 100
HISTORY_FILE = os.path.expanduser('~/.trae_floating_ball_history.json')

# Trae应用路径
DEFAULT_TRAE_PATH = r'C:\Temp\TTT\Trae CN\Trae CN.exe'

# AI服务配置
AI_CONFIG = {
    # AI服务提供商: 'openai', 'anthropic', 'local', 'mock'
    'provider': 'mock',
    
    # OpenAI配置
    'openai': {
        'api_key': '',  # 在此处填写你的OpenAI API密钥
        'model': 'gpt-3.5-turbo',
        'base_url': 'https://api.openai.com/v1',
        'temperature': 0.7,
        'max_tokens': 2000
    },
    
    # Anthropic (Claude)配置
    'anthropic': {
        'api_key': '',  # 在此处填写你的Anthropic API密钥
        'model': 'claude-3-sonnet-20240229',
        'max_tokens': 2000
    },
    
    # 本地模型配置
    'local': {
        'model_path': '',  # 本地模型路径
        'temperature': 0.7
    }
}

# 系统提示词
SYSTEM_PROMPT = """你是Trae悬浮助手，一个桌面级的AI编程助手。你的职责是：
1. 快速回答编程相关问题
2. 提供代码示例和解决方案
3. 帮助诊断程序错误
4. 提供代码审查建议

请保持回答简洁、专业、实用。对于复杂问题，建议用户使用Trae主应用获得更详细的帮助。"""
