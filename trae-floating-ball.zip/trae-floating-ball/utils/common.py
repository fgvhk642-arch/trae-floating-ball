import os
import subprocess

def find_and_launch_trae():
    trae_paths = [
        r'C:\Temp\TTT\Trae CN\Trae CN.exe',
        r'C:\Program Files\Trae CN\Trae CN.exe',
        r'C:\Program Files (x86)\Trae CN\Trae CN.exe',
        os.path.expanduser('~/AppData/Local/Trae CN/Trae CN.exe')
    ]
    
    for path in trae_paths:
        if os.path.exists(path):
            try:
                subprocess.Popen([path], shell=True)
                return True
            except Exception:
                continue
    
    return False

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)
