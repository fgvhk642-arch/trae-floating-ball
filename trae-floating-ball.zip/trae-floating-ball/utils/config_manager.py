import json
import os
from config.settings import AI_CONFIG, FLOATING_BALL_SIZE, FLOATING_BALL_COLOR

class ConfigManager:
    """配置管理器"""
    
    def __init__(self):
        self.config_file = os.path.expanduser('~/.trae_floating_ball_config.json')
        self.config = self.load_config()
    
    def get_default_config(self):
        """获取默认配置"""
        return {
            'ai': {
                'provider': 'mock',
                'openai': {
                    'api_key': '',
                    'model': 'gpt-3.5-turbo',
                    'base_url': 'https://api.openai.com/v1',
                    'temperature': 0.7,
                    'max_tokens': 2000
                },
                'anthropic': {
                    'api_key': '',
                    'model': 'claude-3-sonnet-20240229',
                    'max_tokens': 2000
                }
            },
            'ui': {
                'ball_size': FLOATING_BALL_SIZE,
                'ball_color': FLOATING_BALL_COLOR,
                'chat_window_width': 400,
                'chat_window_height': 600,
                'always_on_top': True
            },
            'general': {
                'auto_start': False,
                'minimize_to_tray': False,
                'show_notifications': True
            }
        }
    
    def load_config(self):
        """加载配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    # 合并默认配置和用户配置
                    default_config = self.get_default_config()
                    return self.merge_config(default_config, config)
        except Exception as e:
            print(f"加载配置失败: {e}")
        
        return self.get_default_config()
    
    def merge_config(self, default, user):
        """合并配置"""
        result = default.copy()
        for key, value in user.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self.merge_config(result[key], value)
            else:
                result[key] = value
        return result
    
    def save_config(self):
        """保存配置"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置失败: {e}")
            return False
    
    def get(self, key, default=None):
        """获取配置项"""
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
    
    def set(self, key, value):
        """设置配置项"""
        keys = key.split('.')
        config = self.config
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        config[keys[-1]] = value
        return self.save_config()
    
    def get_ai_config(self):
        """获取AI配置"""
        return self.config.get('ai', {})
    
    def get_ui_config(self):
        """获取UI配置"""
        return self.config.get('ui', {})
    
    def set_ai_provider(self, provider):
        """设置AI服务提供商"""
        return self.set('ai.provider', provider)
    
    def set_api_key(self, provider, api_key):
        """设置API密钥"""
        return self.set(f'ai.{provider}.api_key', api_key)
    
    def reset_to_default(self):
        """重置为默认配置"""
        self.config = self.get_default_config()
        return self.save_config()
    
    def export_config(self, filepath):
        """导出配置到文件"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"导出配置失败: {e}")
            return False
    
    def import_config(self, filepath):
        """从文件导入配置"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                config = json.load(f)
                self.config = self.merge_config(self.get_default_config(), config)
                return self.save_config()
        except Exception as e:
            print(f"导入配置失败: {e}")
            return False