import random
import os
import json
from config.settings import AI_CONFIG, SYSTEM_PROMPT

class AIService:
    def __init__(self):
        self.provider = AI_CONFIG.get('provider', 'mock')
        self.config = AI_CONFIG.get(self.provider, {})
        self.conversation_history = []
        self.max_history = 10
        
    def _add_to_history(self, role, content):
        """添加消息到对话历史"""
        self.conversation_history.append({
            'role': role,
            'content': content
        })
        # 保持历史记录在限制内
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]
    
    def _call_openai_api(self, message):
        """调用OpenAI API"""
        try:
            import openai
            
            api_key = self.config.get('api_key', '')
            if not api_key:
                return "⚠️ 未配置OpenAI API密钥，请在config/settings.py中设置"
            
            client = openai.OpenAI(
                api_key=api_key,
                base_url=self.config.get('base_url', 'https://api.openai.com/v1')
            )
            
            messages = [
                {'role': 'system', 'content': SYSTEM_PROMPT},
                *self.conversation_history,
                {'role': 'user', 'content': message}
            ]
            
            response = client.chat.completions.create(
                model=self.config.get('model', 'gpt-3.5-turbo'),
                messages=messages,
                temperature=self.config.get('temperature', 0.7),
                max_tokens=self.config.get('max_tokens', 2000)
            )
            
            return response.choices[0].message.content
            
        except ImportError:
            return "⚠️ 未安装openai库，请运行: pip install openai"
        except Exception as e:
            return f"❌ OpenAI API调用失败: {str(e)}"
    
    def _call_anthropic_api(self, message):
        """调用Anthropic (Claude) API"""
        try:
            import anthropic
            
            api_key = self.config.get('api_key', '')
            if not api_key:
                return "⚠️ 未配置Anthropic API密钥，请在config/settings.py中设置"
            
            client = anthropic.Anthropic(api_key=api_key)
            
            # 构建对话历史
            messages = []
            for msg in self.conversation_history:
                messages.append({
                    'role': msg['role'],
                    'content': msg['content']
                })
            messages.append({'role': 'user', 'content': message})
            
            response = client.messages.create(
                model=self.config.get('model', 'claude-3-sonnet-20240229'),
                max_tokens=self.config.get('max_tokens', 2000),
                system=SYSTEM_PROMPT,
                messages=messages
            )
            
            return response.content[0].text
            
        except ImportError:
            return "⚠️ 未安装anthropic库，请运行: pip install anthropic"
        except Exception as e:
            return f"❌ Anthropic API调用失败: {str(e)}"
    
    def _call_local_model(self, message):
        """调用本地模型"""
        # 这里可以集成本地模型，如llama.cpp、transformers等
        return "⚠️ 本地模型功能尚未实现，敬请期待"
    
    def _mock_response(self, message):
        """模拟响应（用于测试）"""
        import time
        time.sleep(0.5)
        
        responses = [
            "好的，我来帮您分析一下这个问题。",
            "这是一个很好的想法！让我思考一下...",
            "我理解您的需求，让我为您提供解决方案。",
            "这个问题很有意思，让我详细解释一下。",
            "感谢您的提问，我来为您解答。",
        ]
        
        if '代码' in message or '编程' in message or 'bug' in message or 'error' in message.lower():
            return "🔧 代码问题分析：\n\n1. 首先检查语法错误\n2. 查看相关文档\n3. 添加适当的日志\n4. 进行单元测试\n\n如果您能提供更多代码细节，我可以给出更具体的建议。"
        elif '截图' in message:
            return "📸 截图功能已经准备就绪！\n\n点击工具栏的📷截图按钮，然后框选您想截取的区域即可。\n截图会自动保存到剪贴板，可以粘贴到对话框中进行分析。"
        elif '帮助' in message or '功能' in message or 'help' in message.lower():
            return "🎯 Trae悬浮助手功能：\n\n🖱️ 拖动悬浮球 - 移动到任意位置\n💬 聊天功能 - 输入问题获取回答\n📷 截图功能 - 框选区域截图\n🗂️ 历史记录 - 自动保存对话\n🤖 AI助手 - 智能问答\n\n有什么可以帮助您的？"
        elif 'hello' in message.lower() or 'hi' in message.lower() or '你好' in message:
            return "👋 您好！我是Trae悬浮助手，很高兴为您服务！\n\n我可以帮助您：\n- 解答编程问题\n- 分析代码错误\n- 提供代码示例\n- 进行代码审查\n\n请问有什么需要帮助的吗？"
        else:
            return random.choice(responses) + "\n\n您说的是：" + message[:100] + ("..." if len(message) > 100 else "")
    
    async def generate_response(self, message):
        """生成AI响应"""
        # 添加用户消息到历史
        self._add_to_history('user', message)
        
        # 根据提供商调用相应的API
        if self.provider == 'openai':
            response = self._call_openai_api(message)
        elif self.provider == 'anthropic':
            response = self._call_anthropic_api(message)
        elif self.provider == 'local':
            response = self._call_local_model(message)
        else:  # mock
            response = self._mock_response(message)
        
        # 添加AI响应到历史
        self._add_to_history('assistant', response)
        
        return response
    
    def generate_instant_response(self, message):
        """生成即时响应（用于快速回复）"""
        message_lower = message.lower().strip()
        
        instant_replies = {
            'hello': "您好！我是您的AI悬浮助手，很高兴为您服务！",
            'hi': "您好！有什么可以帮助您的吗？",
            'bye': "再见！如有需要随时召唤我！",
            '再见': "再见！如有需要随时召唤我！",
            '谢谢': "不客气！还有其他需要帮助的吗？",
            'thanks': "You're welcome! Feel free to ask if you need more help!",
        }
        
        return instant_replies.get(message_lower)
    
    def clear_history(self):
        """清空对话历史"""
        self.conversation_history = []
    
    def set_provider(self, provider):
        """切换AI服务提供商"""
        if provider in ['openai', 'anthropic', 'local', 'mock']:
            self.provider = provider
            self.config = AI_CONFIG.get(provider, {})
            self.clear_history()
            return True
        return False
