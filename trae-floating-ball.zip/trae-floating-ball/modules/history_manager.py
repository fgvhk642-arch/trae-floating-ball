import json
import os
from config.settings import HISTORY_FILE, MAX_HISTORY_SIZE

class HistoryManager:
    def __init__(self):
        self.history = []
        self.load_history()
    
    def load_history(self):
        try:
            if os.path.exists(HISTORY_FILE):
                with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                    self.history = json.load(f)
        except Exception:
            self.history = []
    
    def save_history(self):
        try:
            with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.history[-MAX_HISTORY_SIZE:], f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    
    def add_message(self, role, content):
        message = {
            'role': role,
            'content': content,
            'timestamp': os.times()[4]
        }
        self.history.append(message)
        self.save_history()
    
    def get_history(self, limit=20):
        return self.history[-limit:]
    
    def clear_history(self):
        self.history = []
        self.save_history()
    
    def get_last_message(self):
        if self.history:
            return self.history[-1]
        return None
