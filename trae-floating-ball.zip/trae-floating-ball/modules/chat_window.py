import tkinter as tk
from tkinter import ttk, scrolledtext
import threading

class ChatWindow:
    def __init__(self, parent, history_manager, ai_service, screen_capture):
        self.parent = parent
        self.history_manager = history_manager
        self.ai_service = ai_service
        self.screen_capture = screen_capture
        self.window = None
        self.text_area = None
        self.input_entry = None
    
    def show(self):
        if self.window and self.window.winfo_exists():
            self.window.deiconify()
            self.window.lift()
            return
        
        self.window = tk.Toplevel(self.parent)
        self.window.title('AI聊天')
        self.window.geometry('400x600')
        self.window.attributes('-topmost', True)
        self.window.protocol('WM_DELETE_WINDOW', self.hide)
        
        self.create_widgets()
        self.load_history()
    
    def hide(self):
        if self.window and self.window.winfo_exists():
            self.window.withdraw()
    
    def create_widgets(self):
        toolbar = ttk.Frame(self.window)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        screenshot_btn = ttk.Button(toolbar, text='📷 截图', command=self.on_screenshot)
        screenshot_btn.pack(side=tk.LEFT, padx=2)
        
        clear_btn = ttk.Button(toolbar, text='🗑️ 清空', command=self.clear_history)
        clear_btn.pack(side=tk.LEFT, padx=2)
        
        self.text_area = scrolledtext.ScrolledText(
            self.window,
            wrap=tk.WORD,
            state=tk.DISABLED,
            bg='#f8f9fa',
            font=('微软雅黑', 10)
        )
        self.text_area.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        input_frame = ttk.Frame(self.window)
        input_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.input_entry = ttk.Entry(input_frame)
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        self.input_entry.bind('<Return>', self.send_message)
        
        send_btn = ttk.Button(input_frame, text='发送', command=self.send_message)
        send_btn.pack(side=tk.RIGHT, padx=2)
    
    def add_message(self, role, content):
        self.text_area.config(state=tk.NORMAL)
        
        if role == 'user':
            self.text_area.insert(tk.END, f'您: {content}\n\n', 'user')
        else:
            self.text_area.insert(tk.END, f'AI: {content}\n\n', 'ai')
        
        self.text_area.tag_config('user', foreground='#667eea', font=('微软雅黑', 10, 'bold'))
        self.text_area.tag_config('ai', foreground='#6c757d', font=('微软雅黑', 10))
        
        self.text_area.config(state=tk.DISABLED)
        self.text_area.see(tk.END)
    
    def send_message(self, event=None):
        message = self.input_entry.get().strip()
        if not message:
            return
        
        self.input_entry.delete(0, tk.END)
        self.add_message('user', message)
        self.history_manager.add_message('user', message)
        
        self.add_message('ai', '正在思考...')
        
        def get_response():
            response = self.ai_service.generate_response(message)
            
            self.text_area.config(state=tk.NORMAL)
            self.text_area.delete('end-5c', 'end')
            self.text_area.config(state=tk.DISABLED)
            
            self.add_message('ai', response)
            self.history_manager.add_message('ai', response)
        
        thread = threading.Thread(target=get_response)
        thread.daemon = True
        thread.start()
    
    def load_history(self):
        history = self.history_manager.get_history()
        if not history:
            self.add_message('ai', '您好！我是您的AI悬浮助手，有什么可以帮助您的？')
            return
        
        for message in history:
            self.add_message(message['role'], message['content'])
    
    def clear_history(self):
        self.text_area.config(state=tk.NORMAL)
        self.text_area.delete(1.0, tk.END)
        self.text_area.config(state=tk.DISABLED)
        self.history_manager.clear_history()
        self.add_message('ai', '历史记录已清空！')
    
    def on_screenshot(self):
        self.hide()
        
        def on_capture_done(success):
            if success:
                self.show()
                self.add_message('ai', '截图已完成！截图内容已保存到剪贴板，可以粘贴到对话框中。')
            else:
                self.show()
        
        self.screen_capture.start_capture(on_capture_done)
