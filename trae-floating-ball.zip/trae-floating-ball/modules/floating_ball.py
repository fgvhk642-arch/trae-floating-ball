import tkinter as tk
from config.settings import FLOATING_BALL_SIZE, FLOATING_BALL_COLOR
from utils.common import find_and_launch_trae
from utils.config_manager import ConfigManager
from modules.settings_window import SettingsWindow

class FloatingBall:
    def __init__(self, root, chat_window):
        self.root = root
        self.chat_window = chat_window
        self.config_manager = ConfigManager()
        self.is_dragging = False
        self.offset_x = 0
        self.offset_y = 0
        
        self.setup_window()
        self.create_widgets()
    
    def setup_window(self):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # 从配置读取悬浮球大小
        ball_size = self.config_manager.get('ui.ball_size', FLOATING_BALL_SIZE)
        
        self.root.geometry(f'{ball_size}x{ball_size}+{screen_width - ball_size - 20}+{screen_height - ball_size - 100}')
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        self.root.attributes('-transparentcolor', 'white')
        self.root.attributes('-alpha', 0.9)
    
    def create_widgets(self):
        ball_size = self.config_manager.get('ui.ball_size', FLOATING_BALL_SIZE)
        ball_color = self.config_manager.get('ui.ball_color', FLOATING_BALL_COLOR)
        
        self.canvas = tk.Canvas(
            self.root,
            width=ball_size,
            height=ball_size,
            bg='white',
            highlightthickness=0
        )
        self.canvas.pack()
        
        self.ball = self.canvas.create_oval(
            2, 2,
            ball_size - 2,
            ball_size - 2,
            fill=ball_color,
            outline=''
        )
        
        self.canvas.create_text(
            ball_size // 2,
            ball_size // 2,
            text='AI',
            fill='white',
            font=('微软雅黑', 14, 'bold')
        )
        
        self.trae_button = tk.Button(
            self.root,
            text='●',
            bg='#28a745',
            fg='white',
            bd=0,
            width=1,
            height=1,
            command=self.launch_trae,
            highlightthickness=0,
            activebackground='#20c997'
        )
        self.trae_button.place(x=5, y=5, width=12, height=12)
        
        self.menu_button = tk.Button(
            self.root,
            text='⚡',
            bg='#17a2b8',
            fg='white',
            bd=0,
            width=16,
            height=16,
            font=('Arial', 8),
            command=self.show_menu,
            highlightthickness=0,
            activebackground='#138496'
        )
        self.menu_button.place(x=ball_size - 20, y=ball_size - 20)
        
        self.bind_events()
    
    def bind_events(self):
        self.canvas.bind('<Button-1>', self.on_click)
        self.canvas.bind('<ButtonPress-1>', self.on_drag_start)
        self.canvas.bind('<B1-Motion>', self.on_drag)
        self.canvas.bind('<ButtonRelease-1>', self.on_drag_end)
    
    def on_click(self, event):
        if not self.is_dragging:
            self.chat_window.show()
    
    def on_drag_start(self, event):
        self.is_dragging = False
        self.offset_x = event.x
        self.offset_y = event.y
    
    def on_drag(self, event):
        self.is_dragging = True
        
        x = self.root.winfo_x() + event.x - self.offset_x
        y = self.root.winfo_y() + event.y - self.offset_y
        
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        ball_size = self.config_manager.get('ui.ball_size', FLOATING_BALL_SIZE)
        
        x = max(0, min(x, screen_width - ball_size))
        y = max(0, min(y, screen_height - ball_size))
        
        self.root.geometry(f'+{x}+{y}')
    
    def on_drag_end(self, event):
        self.is_dragging = False
    
    def launch_trae(self):
        success = find_and_launch_trae()
        if not success:
            print('未找到Trae应用')
    
    def show_menu(self):
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label='💬 打开聊天', command=self.chat_window.show)
        menu.add_command(label='📷 截图提问', command=self.chat_window.on_screenshot)
        menu.add_separator()
        menu.add_command(label='⚙️ 设置', command=self.show_settings)
        menu.add_command(label='🗑️ 清空历史', command=self.chat_window.clear_history)
        menu.add_separator()
        menu.add_command(label='🚪 退出', command=self.root.quit)
        
        x = self.root.winfo_x()
        ball_size = self.config_manager.get('ui.ball_size', FLOATING_BALL_SIZE)
        y = self.root.winfo_y() + ball_size
        menu.post(x, y)
    
    def show_settings(self):
        """显示设置窗口"""
        settings_window = SettingsWindow(self.root, self.config_manager)
        settings_window.show()
