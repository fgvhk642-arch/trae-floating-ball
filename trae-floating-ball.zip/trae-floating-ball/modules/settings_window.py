import tkinter as tk
from tkinter import ttk, messagebox
from utils.config_manager import ConfigManager

class SettingsWindow:
    """设置窗口"""
    
    def __init__(self, parent, config_manager=None):
        self.parent = parent
        self.config_manager = config_manager or ConfigManager()
        self.window = None
        
    def show(self):
        """显示设置窗口"""
        if self.window and self.window.winfo_exists():
            self.window.lift()
            return
        
        self.window = tk.Toplevel(self.parent)
        self.window.title('设置')
        self.window.geometry('500x600')
        self.window.resizable(False, False)
        self.window.attributes('-topmost', True)
        
        self.create_widgets()
        self.load_settings()
        
        # 居中显示
        self.window.update_idletasks()
        x = (self.window.winfo_screenwidth() - 500) // 2
        y = (self.window.winfo_screenheight() - 600) // 2
        self.window.geometry(f'+{x}+{y}')
    
    def create_widgets(self):
        """创建控件"""
        # 创建笔记本（标签页）
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # AI设置标签页
        ai_frame = ttk.Frame(notebook)
        notebook.add(ai_frame, text='AI设置')
        self.create_ai_settings(ai_frame)
        
        # UI设置标签页
        ui_frame = ttk.Frame(notebook)
        notebook.add(ui_frame, text='界面设置')
        self.create_ui_settings(ui_frame)
        
        # 通用设置标签页
        general_frame = ttk.Frame(notebook)
        notebook.add(general_frame, text='通用设置')
        self.create_general_settings(general_frame)
        
        # 底部按钮
        button_frame = ttk.Frame(self.window)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        save_btn = ttk.Button(button_frame, text='保存', command=self.save_settings)
        save_btn.pack(side=tk.RIGHT, padx=5)
        
        cancel_btn = ttk.Button(button_frame, text='取消', command=self.window.destroy)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        
        reset_btn = ttk.Button(button_frame, text='重置默认', command=self.reset_settings)
        reset_btn.pack(side=tk.LEFT, padx=5)
    
    def create_ai_settings(self, parent):
        """创建AI设置"""
        # AI提供商选择
        provider_frame = ttk.LabelFrame(parent, text='AI服务提供商', padding=10)
        provider_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.provider_var = tk.StringVar(value='mock')
        providers = [
            ('模拟模式 (测试)', 'mock'),
            ('OpenAI', 'openai'),
            ('Anthropic (Claude)', 'anthropic'),
        ]
        
        for text, value in providers:
            rb = ttk.Radiobutton(
                provider_frame,
                text=text,
                value=value,
                variable=self.provider_var
            )
            rb.pack(anchor=tk.W, pady=2)
        
        # OpenAI设置
        openai_frame = ttk.LabelFrame(parent, text='OpenAI设置', padding=10)
        openai_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(openai_frame, text='API密钥:').grid(row=0, column=0, sticky=tk.W, pady=5)
        self.openai_key_entry = ttk.Entry(openai_frame, width=40, show='*')
        self.openai_key_entry.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(openai_frame, text='模型:').grid(row=1, column=0, sticky=tk.W, pady=5)
        self.openai_model_var = tk.StringVar(value='gpt-3.5-turbo')
        openai_model_combo = ttk.Combobox(
            openai_frame,
            textvariable=self.openai_model_var,
            values=['gpt-3.5-turbo', 'gpt-4', 'gpt-4-turbo'],
            width=37
        )
        openai_model_combo.grid(row=1, column=1, padx=5, pady=5)
        
        # Anthropic设置
        anthropic_frame = ttk.LabelFrame(parent, text='Anthropic设置', padding=10)
        anthropic_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(anthropic_frame, text='API密钥:').grid(row=0, column=0, sticky=tk.W, pady=5)
        self.anthropic_key_entry = ttk.Entry(anthropic_frame, width=40, show='*')
        self.anthropic_key_entry.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(anthropic_frame, text='模型:').grid(row=1, column=0, sticky=tk.W, pady=5)
        self.anthropic_model_var = tk.StringVar(value='claude-3-sonnet-20240229')
        anthropic_model_combo = ttk.Combobox(
            anthropic_frame,
            textvariable=self.anthropic_model_var,
            values=['claude-3-opus-20240229', 'claude-3-sonnet-20240229', 'claude-3-haiku-20240307'],
            width=37
        )
        anthropic_model_combo.grid(row=1, column=1, padx=5, pady=5)
    
    def create_ui_settings(self, parent):
        """创建UI设置"""
        # 悬浮球设置
        ball_frame = ttk.LabelFrame(parent, text='悬浮球设置', padding=10)
        ball_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(ball_frame, text='大小:').grid(row=0, column=0, sticky=tk.W, pady=5)
        self.ball_size_var = tk.IntVar(value=60)
        ball_size_spinbox = ttk.Spinbox(
            ball_frame,
            from_=40,
            to=100,
            textvariable=self.ball_size_var,
            width=10
        )
        ball_size_spinbox.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(ball_frame, text='颜色:').grid(row=1, column=0, sticky=tk.W, pady=5)
        self.ball_color_var = tk.StringVar(value='#667eea')
        ball_color_entry = ttk.Entry(ball_frame, textvariable=self.ball_color_var, width=12)
        ball_color_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 聊天窗口设置
        chat_frame = ttk.LabelFrame(parent, text='聊天窗口设置', padding=10)
        chat_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(chat_frame, text='宽度:').grid(row=0, column=0, sticky=tk.W, pady=5)
        self.chat_width_var = tk.IntVar(value=400)
        chat_width_spinbox = ttk.Spinbox(
            chat_frame,
            from_=300,
            to=800,
            textvariable=self.chat_width_var,
            width=10
        )
        chat_width_spinbox.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(chat_frame, text='高度:').grid(row=1, column=0, sticky=tk.W, pady=5)
        self.chat_height_var = tk.IntVar(value=600)
        chat_height_spinbox = ttk.Spinbox(
            chat_frame,
            from_=400,
            to=1000,
            textvariable=self.chat_height_var,
            width=10
        )
        chat_height_spinbox.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 其他设置
        other_frame = ttk.LabelFrame(parent, text='其他设置', padding=10)
        other_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.always_on_top_var = tk.BooleanVar(value=True)
        always_on_top_check = ttk.Checkbutton(
            other_frame,
            text='窗口始终置顶',
            variable=self.always_on_top_var
        )
        always_on_top_check.pack(anchor=tk.W, pady=5)
    
    def create_general_settings(self, parent):
        """创建通用设置"""
        # 启动设置
        startup_frame = ttk.LabelFrame(parent, text='启动设置', padding=10)
        startup_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.auto_start_var = tk.BooleanVar(value=False)
        auto_start_check = ttk.Checkbutton(
            startup_frame,
            text='开机自动启动',
            variable=self.auto_start_var
        )
        auto_start_check.pack(anchor=tk.W, pady=5)
        
        self.minimize_to_tray_var = tk.BooleanVar(value=False)
        minimize_to_tray_check = ttk.Checkbutton(
            startup_frame,
            text='最小化到系统托盘',
            variable=self.minimize_to_tray_var
        )
        minimize_to_tray_check.pack(anchor=tk.W, pady=5)
        
        # 通知设置
        notification_frame = ttk.LabelFrame(parent, text='通知设置', padding=10)
        notification_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.show_notifications_var = tk.BooleanVar(value=True)
        show_notifications_check = ttk.Checkbutton(
            notification_frame,
            text='显示通知',
            variable=self.show_notifications_var
        )
        show_notifications_check.pack(anchor=tk.W, pady=5)
        
        # 数据管理
        data_frame = ttk.LabelFrame(parent, text='数据管理', padding=10)
        data_frame.pack(fill=tk.X, padx=10, pady=10)
        
        export_btn = ttk.Button(data_frame, text='导出配置', command=self.export_config)
        export_btn.pack(side=tk.LEFT, padx=5, pady=5)
        
        import_btn = ttk.Button(data_frame, text='导入配置', command=self.import_config)
        import_btn.pack(side=tk.LEFT, padx=5, pady=5)
    
    def load_settings(self):
        """加载设置"""
        # AI设置
        self.provider_var.set(self.config_manager.get('ai.provider', 'mock'))
        self.openai_key_entry.insert(0, self.config_manager.get('ai.openai.api_key', ''))
        self.openai_model_var.set(self.config_manager.get('ai.openai.model', 'gpt-3.5-turbo'))
        self.anthropic_key_entry.insert(0, self.config_manager.get('ai.anthropic.api_key', ''))
        self.anthropic_model_var.set(self.config_manager.get('ai.anthropic.model', 'claude-3-sonnet-20240229'))
        
        # UI设置
        self.ball_size_var.set(self.config_manager.get('ui.ball_size', 60))
        self.ball_color_var.set(self.config_manager.get('ui.ball_color', '#667eea'))
        self.chat_width_var.set(self.config_manager.get('ui.chat_window_width', 400))
        self.chat_height_var.set(self.config_manager.get('ui.chat_window_height', 600))
        self.always_on_top_var.set(self.config_manager.get('ui.always_on_top', True))
        
        # 通用设置
        self.auto_start_var.set(self.config_manager.get('general.auto_start', False))
        self.minimize_to_tray_var.set(self.config_manager.get('general.minimize_to_tray', False))
        self.show_notifications_var.set(self.config_manager.get('general.show_notifications', True))
    
    def save_settings(self):
        """保存设置"""
        # AI设置
        self.config_manager.set('ai.provider', self.provider_var.get())
        self.config_manager.set('ai.openai.api_key', self.openai_key_entry.get())
        self.config_manager.set('ai.openai.model', self.openai_model_var.get())
        self.config_manager.set('ai.anthropic.api_key', self.anthropic_key_entry.get())
        self.config_manager.set('ai.anthropic.model', self.anthropic_model_var.get())
        
        # UI设置
        self.config_manager.set('ui.ball_size', self.ball_size_var.get())
        self.config_manager.set('ui.ball_color', self.ball_color_var.get())
        self.config_manager.set('ui.chat_window_width', self.chat_width_var.get())
        self.config_manager.set('ui.chat_window_height', self.chat_height_var.get())
        self.config_manager.set('ui.always_on_top', self.always_on_top_var.get())
        
        # 通用设置
        self.config_manager.set('general.auto_start', self.auto_start_var.get())
        self.config_manager.set('general.minimize_to_tray', self.minimize_to_tray_var.get())
        self.config_manager.set('general.show_notifications', self.show_notifications_var.get())
        
        messagebox.showinfo('成功', '设置已保存！部分设置需要重启应用才能生效。')
        self.window.destroy()
    
    def reset_settings(self):
        """重置设置"""
        if messagebox.askyesno('确认', '确定要重置所有设置为默认值吗？'):
            self.config_manager.reset_to_default()
            self.load_settings()
            messagebox.showinfo('成功', '设置已重置为默认值！')
    
    def export_config(self):
        """导出配置"""
        from tkinter import filedialog
        filepath = filedialog.asksaveasfilename(
            defaultextension='.json',
            filetypes=[('JSON文件', '*.json'), ('所有文件', '*.*')],
            title='导出配置'
        )
        if filepath:
            if self.config_manager.export_config(filepath):
                messagebox.showinfo('成功', f'配置已导出到:\n{filepath}')
            else:
                messagebox.showerror('错误', '导出配置失败！')
    
    def import_config(self):
        """导入配置"""
        from tkinter import filedialog
        filepath = filedialog.askopenfilename(
            filetypes=[('JSON文件', '*.json'), ('所有文件', '*.*')],
            title='导入配置'
        )
        if filepath:
            if self.config_manager.import_config(filepath):
                self.load_settings()
                messagebox.showinfo('成功', '配置已导入！')
            else:
                messagebox.showerror('错误', '导入配置失败！')