import tkinter as tk
from PIL import ImageGrab, ImageTk
from io import BytesIO
import pyperclip
import platform

class ScreenCapture:
    def __init__(self, root):
        self.root = root
        self.screenshot = None
        self.start_x = 0
        self.start_y = 0
        self.current_x = 0
        self.current_y = 0
        self.is_capturing = False
        self.capture_window = None
        self.canvas = None
        self.rect = None
        self.captured_image = None
    
    def start_capture(self, callback=None):
        """开始截图"""
        self.callback = callback
        try:
            self.screenshot = ImageGrab.grab()
            self.show_capture_window()
        except Exception as e:
            print(f"截图失败: {e}")
            if self.callback:
                self.callback(False)
    
    def show_capture_window(self):
        """显示截图窗口"""
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        self.capture_window = tk.Toplevel()
        self.capture_window.attributes('-fullscreen', True)
        self.capture_window.attributes('-alpha', 0.3)
        self.capture_window.attributes('-topmost', True)
        self.capture_window.configure(bg='black')
        
        # 显示提示信息
        tip_label = tk.Label(
            self.capture_window,
            text="按住鼠标左键拖动选择截图区域，按 ESC 取消",
            bg='yellow',
            fg='black',
            font=('微软雅黑', 14, 'bold'),
            padx=20,
            pady=10
        )
        tip_label.pack(pady=20)
        
        self.canvas = tk.Canvas(
            self.capture_window,
            cursor='cross',
            bg='gray',
            highlightthickness=0
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.canvas.bind('<ButtonPress-1>', self.on_mouse_down)
        self.canvas.bind('<B1-Motion>', self.on_mouse_drag)
        self.canvas.bind('<ButtonRelease-1>', self.on_mouse_up)
        self.capture_window.bind('<Escape>', self.cancel_capture)
        
        # 聚焦窗口
        self.capture_window.focus_force()
    
    def on_mouse_down(self, event):
        """鼠标按下事件"""
        self.is_capturing = True
        self.start_x = event.x
        self.start_y = event.y
        self.current_x = event.x
        self.current_y = event.y
    
    def on_mouse_drag(self, event):
        """鼠标拖动事件"""
        if not self.is_capturing:
            return
        
        self.current_x = event.x
        self.current_y = event.y
        
        # 删除旧的矩形
        if self.rect:
            self.canvas.delete(self.rect)
        
        # 计算矩形坐标
        x1 = min(self.start_x, self.current_x)
        y1 = min(self.start_y, self.current_y)
        x2 = max(self.start_x, self.current_x)
        y2 = max(self.start_y, self.current_y)
        
        # 绘制新的矩形
        self.rect = self.canvas.create_rectangle(
            x1, y1, x2, y2,
            outline='red',
            width=3,
            dash=(5, 5)
        )
        
        # 显示尺寸信息
        self.canvas.delete('size_text')
        width = abs(x2 - x1)
        height = abs(y2 - y1)
        size_text = f"{width} × {height}"
        self.canvas.create_text(
            (x1 + x2) // 2, y1 - 10,
            text=size_text,
            fill='white',
            font=('Arial', 12, 'bold'),
            tags='size_text'
        )
    
    def on_mouse_up(self, event):
        """鼠标释放事件"""
        if not self.is_capturing:
            return
        
        self.is_capturing = False
        
        # 计算截图区域
        x1 = min(self.start_x, self.current_x)
        y1 = min(self.start_y, self.current_y)
        x2 = max(self.start_x, self.current_x)
        y2 = max(self.start_y, self.current_y)
        
        # 检查截图区域大小
        if (x2 - x1) > 10 and (y2 - y1) > 10:
            # 裁剪图片
            self.captured_image = self.screenshot.crop((x1, y1, x2, y2))
            
            # 显示确认窗口
            self.show_confirmation(x1, y1, x2, y2)
        else:
            self.cancel_capture()
    
    def show_confirmation(self, x1, y1, x2, y2):
        """显示截图确认窗口"""
        self.capture_window.destroy()
        
        confirm_window = tk.Toplevel()
        confirm_window.title('截图完成')
        confirm_window.attributes('-topmost', True)
        
        # 显示截图预览
        img_tk = ImageTk.PhotoImage(self.captured_image)
        label = tk.Label(confirm_window, image=img_tk)
        label.image = img_tk
        label.pack(padx=10, pady=10)
        
        # 按钮框架
        frame = tk.Frame(confirm_window)
        frame.pack(pady=10)
        
        def on_confirm():
            self.copy_image_to_clipboard()
            confirm_window.destroy()
            if self.callback:
                self.callback(True)
        
        def on_cancel():
            confirm_window.destroy()
            if self.callback:
                self.callback(False)
        
        confirm_btn = tk.Button(
            frame,
            text='✓ 复制到剪贴板',
            command=on_confirm,
            bg='#28a745',
            fg='white',
            font=('微软雅黑', 10),
            padx=15,
            pady=5
        )
        confirm_btn.pack(side=tk.LEFT, padx=5)
        
        cancel_btn = tk.Button(
            frame,
            text='✗ 取消',
            command=on_cancel,
            bg='#dc3545',
            fg='white',
            font=('微软雅黑', 10),
            padx=15,
            pady=5
        )
        cancel_btn.pack(side=tk.LEFT, padx=5)
        
        # 居中显示窗口
        confirm_window.update_idletasks()
        width = confirm_window.winfo_width()
        height = confirm_window.winfo_height()
        x = (confirm_window.winfo_screenwidth() // 2) - (width // 2)
        y = (confirm_window.winfo_screenheight() // 2) - (height // 2)
        confirm_window.geometry(f'+{x}+{y}')
    
    def copy_image_to_clipboard(self):
        """复制图片到剪贴板"""
        if not self.captured_image:
            return
        
        try:
            if platform.system() == 'Windows':
                # Windows系统使用win32clipboard
                import win32clipboard
                import win32con
                
                # 将图片转换为BMP格式
                output = BytesIO()
                self.captured_image.save(output, 'BMP')
                data = output.getvalue()[14:]  # 去掉BMP文件头
                
                win32clipboard.OpenClipboard()
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardData(win32con.CF_DIB, data)
                win32clipboard.CloseClipboard()
            else:
                # 其他系统尝试使用pyperclip
                output = BytesIO()
                self.captured_image.save(output, format='PNG')
                pyperclip.copy(output.getvalue())
        except Exception as e:
            print(f"复制到剪贴板失败: {e}")
            # 如果复制失败，保存到临时文件
            try:
                import tempfile
                import os
                temp_dir = tempfile.gettempdir()
                temp_file = os.path.join(temp_dir, 'trae_screenshot.png')
                self.captured_image.save(temp_file)
                print(f"截图已保存到: {temp_file}")
            except Exception as e2:
                print(f"保存截图失败: {e2}")
    
    def cancel_capture(self, event=None):
        """取消截图"""
        if self.capture_window:
            self.capture_window.destroy()
        self.is_capturing = False
        if self.callback:
            self.callback(False)
