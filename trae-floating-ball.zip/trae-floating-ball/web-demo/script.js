class FloatingBall {
    constructor() {
        this.ball = document.getElementById('floatingBall');
        this.chatWindow = document.getElementById('chatWindow');
        this.isDragging = false;
        this.offset = { x: 0, y: 0 };
        this.isChatOpen = false;
        
        this.init();
    }

    init() {
        this.ball.addEventListener('mousedown', this.startDrag.bind(this));
        this.ball.addEventListener('click', this.toggleChat.bind(this));
        document.addEventListener('mousemove', this.onDrag.bind(this));
        document.addEventListener('mouseup', this.stopDrag.bind(this));

        document.getElementById('minimizeBtn').addEventListener('click', this.toggleChat.bind(this));
        document.getElementById('closeBtn').addEventListener('click', this.hideChat.bind(this));
        
        this.initScreenshot();
        this.initChat();
    }

    startDrag(e) {
        if (e.button === 0) {
            this.isDragging = true;
            this.offset = {
                x: e.clientX - this.ball.getBoundingClientRect().left,
                y: e.clientY - this.ball.getBoundingClientRect().top
            };
            this.ball.classList.add('dragging');
            e.stopPropagation();
        }
    }

    onDrag(e) {
        if (this.isDragging) {
            e.preventDefault();
            let x = e.clientX - this.offset.x;
            let y = e.clientY - this.offset.y;
            
            const maxX = window.innerWidth - this.ball.offsetWidth;
            const maxY = window.innerHeight - this.ball.offsetHeight;
            
            x = Math.max(0, Math.min(x, maxX));
            y = Math.max(0, Math.min(y, maxY));
            
            this.ball.style.left = x + 'px';
            this.ball.style.right = 'auto';
            this.ball.style.top = y + 'px';
            this.ball.style.bottom = 'auto';
        }
    }

    stopDrag() {
        this.isDragging = false;
        this.ball.classList.remove('dragging');
    }

    toggleChat(e) {
        if (!this.isDragging) {
            this.isChatOpen = !this.isChatOpen;
            this.chatWindow.classList.toggle('show', this.isChatOpen);
        }
    }

    hideChat() {
        this.isChatOpen = false;
        this.chatWindow.classList.remove('show');
    }

    initScreenshot() {
        const screenshotBtn = document.getElementById('screenshotBtn');
        const overlay = document.getElementById('screenshotOverlay');
        const confirmBtn = document.getElementById('confirmScreenshot');
        const cancelBtn = document.getElementById('cancelScreenshot');
        const screenshotArea = document.getElementById('screenshotArea');
        
        let isSelecting = false;
        let startPos = { x: 0, y: 0 };
        let selectionBox = null;

        screenshotBtn.addEventListener('click', () => {
            this.hideChat();
            setTimeout(() => {
                overlay.style.display = 'flex';
            }, 300);
        });

        cancelBtn.addEventListener('click', () => {
            overlay.style.display = 'none';
            if (selectionBox) {
                selectionBox.remove();
                selectionBox = null;
            }
        });

        screenshotArea.addEventListener('mousedown', (e) => {
            if (e.target === screenshotArea || e.target.classList.contains('screenshot-hint')) {
                isSelecting = true;
                startPos = { x: e.clientX, y: e.clientY };
                
                selectionBox = document.createElement('div');
                selectionBox.className = 'selection-box';
                selectionBox.style.left = startPos.x + 'px';
                selectionBox.style.top = startPos.y + 'px';
                selectionBox.style.width = '0px';
                selectionBox.style.height = '0px';
                screenshotArea.appendChild(selectionBox);
            }
        });

        document.addEventListener('mousemove', (e) => {
            if (isSelecting && selectionBox) {
                const width = Math.abs(e.clientX - startPos.x);
                const height = Math.abs(e.clientY - startPos.y);
                const left = Math.min(startPos.x, e.clientX);
                const top = Math.min(startPos.y, e.clientY);
                
                selectionBox.style.left = left + 'px';
                selectionBox.style.top = top + 'px';
                selectionBox.style.width = width + 'px';
                selectionBox.style.height = height + 'px';
            }
        });

        document.addEventListener('mouseup', () => {
            if (isSelecting) {
                isSelecting = false;
            }
        });

        screenshotArea.addEventListener('dblclick', () => {
            if (selectionBox) {
                this.captureSelection(selectionBox);
            }
        });

        confirmBtn.addEventListener('click', () => {
            if (selectionBox) {
                this.captureSelection(selectionBox);
            }
        });
    }

    async captureSelection(box) {
        const overlay = document.getElementById('screenshotOverlay');
        
        const rect = box.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;
        const x = rect.left + overlay.getBoundingClientRect().left;
        const y = rect.top + overlay.getBoundingClientRect().top;

        try {
            const stream = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    displaySurface: 'monitor',
                    logicalSurface: true
                },
                audio: false
            });

            const video = document.createElement('video');
            video.srcObject = stream;
            await video.play();

            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            
            ctx.drawImage(video, x, y, width, height, 0, 0, width, height);
            
            stream.getTracks().forEach(track => track.stop());

            const imageData = canvas.toDataURL('image/png');
            
            overlay.style.display = 'none';
            if (box) {
                box.remove();
                box = null;
            }

            setTimeout(() => {
                this.showChat();
                this.insertImageToInput(imageData);
            }, 200);

        } catch (error) {
            console.error('截图失败:', error);
            alert('截图功能需要屏幕录制权限，请在浏览器设置中开启');
            overlay.style.display = 'none';
            if (box) {
                box.remove();
                box = null;
            }
        }
    }

    insertImageToInput(imageData) {
        const input = document.getElementById('messageInput');
        
        if (input) {
            const currentValue = input.value;
            input.value = currentValue + '\n[图片已插入]\n';
            input.focus();
            
            if (navigator.clipboard) {
                fetch(imageData)
                    .then(res => res.blob())
                    .then(blob => {
                        const item = new ClipboardItem({ 'image/png': blob });
                        navigator.clipboard.write([item]).then(() => {
                            console.log('图片已复制到剪贴板');
                        }).catch(err => {
                            console.log('剪贴板复制失败:', err);
                        });
                    });
            }
        }
    }

    showChat() {
        this.isChatOpen = true;
        this.chatWindow.classList.add('show');
    }

    initChat() {
        const sendBtn = document.getElementById('sendBtn');
        const input = document.getElementById('messageInput');
        
        sendBtn.addEventListener('click', this.sendMessage.bind(this));
        
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    }

    sendMessage() {
        const input = document.getElementById('messageInput');
        const messagesContainer = document.getElementById('chatMessages');
        
        const message = input.value.trim();
        if (!message) return;

        const userMessage = document.createElement('div');
        userMessage.className = 'message user-message';
        userMessage.innerHTML = `
            <div class="avatar">U</div>
            <div class="message-content">
                <p>${this.escapeHtml(message)}</p>
            </div>
        `;
        messagesContainer.appendChild(userMessage);
        
        input.value = '';
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        setTimeout(() => {
            this.simulateBotResponse(message);
        }, 800);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    simulateBotResponse(userMessage) {
        const messagesContainer = document.getElementById('chatMessages');
        
        const responses = [
            '好的，我明白你的需求了。让我来帮你分析一下。',
            '这个问题很有意思！让我仔细思考一下...',
            '谢谢你的提问，我来为你解答。',
            '根据你的描述，我认为可以这样处理：',
            '我理解你的想法，以下是我的建议：'
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        
        const botMessage = document.createElement('div');
        botMessage.className = 'message bot-message';
        botMessage.innerHTML = `
            <div class="avatar">T</div>
            <div class="message-content">
                <p>${randomResponse}</p>
                <p>你输入的内容：${this.escapeHtml(userMessage)}</p>
            </div>
        `;
        
        messagesContainer.appendChild(botMessage);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new FloatingBall();
});