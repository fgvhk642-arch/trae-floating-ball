const { app, BrowserWindow, ipcMain, Tray, Menu } = require('electron');
const path = require('path');
const axios = require('axios');

let floatWindow;
let chatWindow;
let tray;

// 隐藏Electron默认菜单栏
Menu.setApplicationMenu(null);

// 创建悬浮球窗口
function createFloatWindow() {
  const screenSize = require('electron').screen.getPrimaryDisplay().workAreaSize;
  
  floatWindow = new BrowserWindow({
    width: 60,
    height: 60,
    x: screenSize.width - 90,
    y: screenSize.height - 160,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  floatWindow.loadFile('float-ball.html');
  
  // 悬浮球窗口始终在最上层
  floatWindow.setAlwaysOnTop(true, 'screen-saver');
}

// 创建聊天窗口
function createChatWindow() {
  const screenSize = require('electron').screen.getPrimaryDisplay().workAreaSize;
  const floatBounds = floatWindow.getBounds();
  
  chatWindow = new BrowserWindow({
    width: 400,
    height: 600,
    x: Math.max(0, floatBounds.x - 400 + 60),
    y: Math.max(0, floatBounds.y - 600),
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    show: false,
    resizable: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  chatWindow.loadFile('chat-window.html');
  
  // 聊天窗口关闭时隐藏而不是销毁
  chatWindow.on('close', (e) => {
    e.preventDefault();
    chatWindow.hide();
  });
}

// 创建系统托盘
function createTray() {
  const iconPath = path.join(__dirname, 'icon.png');
  
  let trayIcon = iconPath;
  if (!require('fs').existsSync(iconPath)) {
    trayIcon = path.join(__dirname, 'float-ball.html');
  }
  
  tray = new Tray(trayIcon);
  const contextMenu = Menu.buildFromTemplate([
    { label: '显示聊天', click: () => { if (chatWindow) chatWindow.show(); } },
    { label: '隐藏聊天', click: () => { if (chatWindow) chatWindow.hide(); } },
    { type: 'separator' },
    { label: '退出', click: () => {
      if (chatWindow) chatWindow.destroy();
      if (floatWindow) floatWindow.destroy();
      app.quit();
    }}
  ]);
  tray.setToolTip('AI悬浮助手');
  tray.setContextMenu(contextMenu);
  
  tray.on('click', () => {
    if (chatWindow) {
      if (chatWindow.isVisible()) {
        chatWindow.hide();
      } else {
        chatWindow.show();
      }
    }
  });
}

// 处理AI聊天请求
ipcMain.handle('send-message', async (event, message) => {
  try {
    // 这里使用内置的AI响应逻辑
    const response = generateResponse(message);
    return {
      success: true,
      content: response
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
});

// 生成AI响应
function generateResponse(message) {
  const msgLower = message.toLowerCase();
  
  if (msgLower.includes('代码') || msgLower.includes('coding') || msgLower.includes('program')) {
    return `好的，我来帮你编写代码！\n\n请告诉我你需要什么语言的代码，以及具体的功能需求。例如：\n• Python 快速排序算法\n• JavaScript 防抖函数\n• Java 单例模式\n\n我会为你生成完整的代码示例和使用说明！`;
  }
  
  if (msgLower.includes('错误') || msgLower.includes('error') || msgLower.includes('bug')) {
    return `我来帮你诊断问题！\n\n请提供以下信息：\n1. 完整的错误信息\n2. 相关代码片段\n3. 你期望的结果\n4. 实际发生的情况\n\n我会帮你定位问题并提供解决方案！`;
  }
  
  if (msgLower.includes('帮助') || msgLower.includes('help') || msgLower.includes('怎么')) {
    return `我可以帮你做很多事情！例如：\n\n💻 代码编写 - Python、JavaScript、Java等\n🐛 错误诊断 - 分析程序错误\n📝 文档撰写 - 编写技术文档\n💡 创意灵感 - 提供创意建议\n\n请告诉我你需要什么帮助？`;
  }
  
  const responses = [
    '好的，我来帮你分析这个问题！',
    '我理解你的需求了，让我来帮你解决！',
    '没问题，我可以帮你处理这个任务！',
    '好的，我来为你提供详细的解答！'
  ];
  
  return responses[Math.floor(Math.random() * responses.length)] + '\n\n请告诉我更多细节，我会为你提供更具体的帮助！';
}

// 切换聊天窗口显示/隐藏
ipcMain.on('toggle-chat', () => {
  if (!chatWindow) {
    createChatWindow();
  }
  
  if (chatWindow.isVisible()) {
    chatWindow.hide();
  } else {
    chatWindow.show();
  }
});

// 移动悬浮球窗口
ipcMain.on('move-float-window', (event, x, y) => {
  if (floatWindow) {
    const screenSize = require('electron').screen.getPrimaryDisplay().workAreaSize;
    const maxX = screenSize.width - 60;
    const maxY = screenSize.height - 60;
    
    const boundedX = Math.max(0, Math.min(x, maxX));
    const boundedY = Math.max(0, Math.min(y, maxY));
    
    floatWindow.setPosition(boundedX, boundedY);
  }
});

app.whenReady().then(() => {
  createFloatWindow();
  createChatWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createFloatWindow();
    createChatWindow();
  }
});