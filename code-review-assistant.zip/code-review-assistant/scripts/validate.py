import os
import re
import yaml

def validate_skill_md(filepath):
    if not os.path.exists(filepath):
        print(f"❌ 错误：文件不存在 - {filepath}")
        return False
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if not content.startswith('---'):
        print("❌ 错误：缺少 YAML frontmatter 开头")
        return False
    
    frontmatter_end = content.find('\n---\n')
    if frontmatter_end == -1:
        print("❌ 错误：YAML frontmatter 未正确关闭")
        return False
    
    frontmatter = content[4:frontmatter_end]
    
    try:
        metadata = yaml.safe_load(frontmatter)
    except yaml.YAMLError as e:
        print(f"❌ 错误：YAML 解析失败 - {e}")
        return False
    
    required_fields = ['name', 'description', 'trigger']
    for field in required_fields:
        if field not in metadata:
            print(f"❌ 错误：缺少必需字段 '{field}'")
            return False
        if not metadata[field] or not str(metadata[field]).strip():
            print(f"❌ 错误：字段 '{field}' 不能为空")
            return False
    
    print("✅ SKILL.md 验证通过")
    print(f"   名称: {metadata['name']}")
    print(f"   描述: {metadata['description']}")
    print(f"   触发词: {metadata['trigger']}")
    return True

if __name__ == '__main__':
    skill_file = os.path.join(os.path.dirname(__file__), '..', 'SKILL.md')
    validate_skill_md(skill_file)