# 代码审查报告

## 📋 基本信息

| 项目 | 说明 |
|------|------|
| 审查日期 | {{DATE}} |
| 代码位置 | {{FILE_PATH}} |
| 编程语言 | {{LANGUAGE}} |
| 审查人 | Code Review Assistant |

## 📊 总体评价

{{OVERALL_RATING}} - {{OVERALL_COMMENT}}

## 🎯 问题清单

### 🔴 严重问题

{{CRITICAL_ISSUES}}

### 🟡 中等问题

{{MEDIUM_ISSUES}}

### 🟢 优化建议

{{IMPROVEMENTS}}

## 💡 改进方案

{{SOLUTIONS}}

## 📝 总结

{{SUMMARY}}